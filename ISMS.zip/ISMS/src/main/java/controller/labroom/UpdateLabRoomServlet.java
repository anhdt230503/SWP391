/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller.labroom;

import dao.LabRoomDAO;
import dao.MentorDAO;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.List;
import model.LabRoom;
import model.Mentor;

/**
 *
 * @author Huynguyen
 */
public class UpdateLabRoomServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet UpdateLabRoomServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet UpdateLabRoomServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int roomId = Integer.parseInt(request.getParameter("roomId"));
        LabRoomDAO labRoomDAO = new LabRoomDAO();
        LabRoom labRoom = labRoomDAO.getLabRoomById(roomId);

        MentorDAO mentorDAO = new MentorDAO();
        List<Mentor> listOfMentors = mentorDAO.getAllMentors();

        request.setAttribute("labRoom", labRoom);
        request.setAttribute("listOfMentors", listOfMentors);
        request.getRequestDispatcher("UpdateLabRoom.jsp").forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int roomId = Integer.parseInt(request.getParameter("roomId"));
        String roomName = request.getParameter("roomName");
        boolean isAssigned = request.getParameter("mentorId") != null && !request.getParameter("mentorId").isEmpty();
        int mentorId = isAssigned ? Integer.parseInt(request.getParameter("mentorId")) : 0;

        LabRoomDAO labRoomDAO = new LabRoomDAO();

        if (labRoomDAO.isDuplicateRoomNameUpdate(roomName, roomId)) {
            LabRoom labRoom = labRoomDAO.getLabRoomById(roomId);
            MentorDAO mentorDAO = new MentorDAO();
            List<Mentor> listOfMentors = mentorDAO.getAllMentors();

            request.setAttribute("labRoom", labRoom);
            request.setAttribute("listOfMentors", listOfMentors);
            request.setAttribute("errorMessage", "Lab room name already exists. Please choose a different name.");
            request.getRequestDispatcher("UpdateLabRoom.jsp").forward(request, response);
        } else {
            LabRoom labRoom = new LabRoom();
            labRoom.setRoomId(roomId);
            labRoom.setRoomName(roomName);
            labRoom.setAssigned(isAssigned);
            labRoom.setMentorId(mentorId);

            labRoomDAO.updateLabRoom(labRoom);

            response.sendRedirect(request.getContextPath() + "/ListLabRoomsServlet");
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
